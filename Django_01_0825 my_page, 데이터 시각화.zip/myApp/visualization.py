import folium
import json
import glob
import os
import pandas as pd
import numpy as np

class Visualization:

    def __init__(self):
        self.df = pd.read_csv('./data/older_population.csv')
        self.df2 = pd.read_csv('./data/library.csv')
        self.geo_data = './data/seoul-dong.geojson'

    def get_figure(self, area):
        center = [37.541, 126.986]

        m = folium.Map(location=center, zoom_start=10)

        if area is None or area == '동':
            folium.Choropleth(
                geo_data=self.geo_data,
                data=self.df,
                columns=('동', '인구'),
                key_on='feature.properties.동',
                fill_color='BuPu',
                legend_name='노령 인구수'
            ).add_to(m)
        else:
            df_adm = self.df.groupby(['구'])['인구'].sum().to_frame().reset_index()
            folium.Choropleth(
                geo_data=self.geo_data,
                data=df_adm,
                columns=('구', '인구'),
                key_on='feature.properties.구',
                fill_color='BuPu',
                legend_name='노령 인구수'
            ).add_to(m)

        figure = folium.Figure()
        m.add_to(figure)
        figure.render()

        return figure

    def get_library_figure(self):

        dataset = self.df2[['도서관명', '시도명', '시군구명', '위도', '경도']]
        df_library = dataset[(dataset['시도명'] == '서울특별시')]

        data_size = len(df_library)

        center = [37.541, 126.986]

        library_gu = df_library.groupby('시군구명')['도서관명'].count().to_frame().sort_values(by='도서관명', ascending=False)
        library_gu = library_gu.reset_index()
        library_gu = library_gu.set_index('시군구명')

        m = folium.Map(location=center, zoom_start=10)
        folium.Choropleth(geo_data=self.geo_data,
                          data=library_gu['도서관명'],
                          columns=[library_gu.index, library_gu['도서관명']],
                          fill_color='BuPu',
                          key_on='feature.properties.구'
                          ).add_to(m)

        figure = folium.Figure()
        m.add_to(figure)
        figure.render()

        return figure
