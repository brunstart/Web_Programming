from django.urls import path
from . import views

urlpatterns = [
    path('helloworld/', views.helloworld, name='helloworld'),
    path('', views.post_list, name='post_list'),
    path('create_post/', views.create_post, name='create_post')
]