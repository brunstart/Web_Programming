from django.shortcuts import render, redirect
from .models import Post

# Create your views here.


def helloworld(request):
    return render(request, 'helloworld.html')

def post_list(request):
    posts = Post.objects.all().order_by('-created_date')

    return render(request, 'post_list.html', {
        'posts': posts
    })

def create_post(request):
    if request.method == 'POST':
        title = request.POST['title']
        author = request.POST['author']
        content = request.POST['content']
        Post.objects.create(title=title, author=author, content=content)

        return redirect('/')

    return render(request, 'create_post.html')

