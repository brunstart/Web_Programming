from django.shortcuts import render, redirect
from .forms import SignUpForm
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.contrib import messages

# Create your views here.

def sign_up(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            User.objects.create_user(username=form.instance.username,
                                     password=form.instance.password,
                                     email=form.instance.email,
                                     last_name=form.instance.last_name,)
            user = User.objects.get(username=form.instance.username)
            messages.info(request, '회원가입이 완료되었습니다.')
            return redirect('/')
        else:
            messages.info(request, '회원가입을 실패했습니다.')
            return redirect('sign_up')

    else:
        form = SignUpForm
    return render(request, 'accounts/sign_up.html',{
        'form':form,
    })

def sign_in(request):
    if request.method == 'POST':
        u_id = request.POST['u_id']
        u_pw = request.POST['u_pw']
        user = authenticate(request, username=u_id, password=u_pw)

        if user is not None:
            login(request, user)
            return redirect('/')
        else:
            messages.info(request, '로그인에 실패했습니다.')
            return redirect('sign_in')
    else:
        return render(request, 'accounts/sign_in.html')

def sign_out(request):
    logout(request)
    messages.info(request, '로그아웃 되었습니다.')
    return redirect('/')

def my_page(request):
    return render(request, 'accounts/my_page.html')