from django.shortcuts import render

# Create your views here.

def home(request):
    return render(request, 'home.html')

def my_page(request):
    return render(request, 'my_page.html')

def word_count(request):
    return render(request, 'word_count.html')

def count(request):
    full_text = request.GET['full_text']
    words = full_text.split()
    word_dict = {}
    for i in words:
        if i in word_dict:
            word_dict[i] += 1
        else:
            word_dict[i] = 1
    return render(request, 'word_count.html',
                  {'full_text': full_text, 'word_dict': word_dict.items()})